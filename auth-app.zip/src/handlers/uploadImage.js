const AWS = require("aws-sdk");

const S3 = new AWS.S3();
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.TABLE_NAME;
const BUCKET_NAME = process.env.BUCKET_NAME;

const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST",
  "Access-Control-Allow-Headers": "Content-Type",
};

exports.handler = async (event) => {
  try {
    const { email, image } = JSON.parse(event.body);

    // Convert base64 to Buffer
    const buffer = Buffer.from(image, "base64");
    const key = `profile-images/${email}.jpg`;

    // Upload to S3
    await S3.putObject({
      Bucket: BUCKET_NAME,
      Key: key,
      Body: buffer,
      ContentType: "image/jpeg",
      ACL: "public-read",
    }).promise();

    const imageUrl = `https://${BUCKET_NAME}.s3.amazonaws.com/${key}`;

    // Update user profile in DynamoDB
    await dynamoDB
      .update({
        TableName: TABLE_NAME,
        Key: { email },
        UpdateExpression: "set profileImage = :img",
        ExpressionAttributeValues: { ":img": imageUrl },
      })
      .promise();

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ message: "Image uploaded", imageUrl }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
